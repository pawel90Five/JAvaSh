import java.util.Scanner;


public class JAvaSh
{
    //Метод проеобразования арабских цифр в римские
    static String intToRom4ik(int number)
    {
        if (number < 0)
        {
            System.out.println("Не бывет отрицательных римских цифр");
            System.exit(0);
        }
        String[] sotni = {"", "C"};
        String[] desyatki = {"","X","XX","XXX","XL","L","LX","LXX","LXXX","XC"};
        String[] edinici = {"", "I","II","III","IV","V","VI","VII","VIII","IX"};
        return sotni[(number % 1000)/100] + desyatki[(number % 100) / 10] + edinici[number % 10];
    }

    //Метод проеобразования римских цифр в арабские
    static int rom4ikToInt(String rimNumber)
    {

        String[] cifra = {"", "I","II","III","IV","V","VI","VII","VIII","IX","X"};
        for (int i = 0; i < cifra.length; i++)
        {
            if (rimNumber.equals(cifra[i]))
            {
                return i;
            }
        }
        return -1;
    }




    public static void main(String[] args)
    {
        int num1 = 0, num2 = 0;
        Scanner in = new Scanner(System.in);

        System.out.print("Введите выражение: ");
        String expression = in.nextLine();

        String[] massExpression = expression.split(" ");



        //Проверка на длину выражения
        try{
            if (massExpression.length != 3){
                throw new Exception("Неверное количество операторов или операндов");}
        }
        catch (Exception ex) {
            System.out.println(ex.getMessage());

            System.exit(0);
        }
        //Проверка на то, римские ли цифры
          int rimOrNot1 = rom4ikToInt(massExpression[0]);
          int rimOrNot2 = rom4ikToInt(massExpression[2]);
            if (rimOrNot1 != -1 && rimOrNot2 == -1 || rimOrNot1 == -1 && rimOrNot2 != -1 )
            {
                System.out.println("Ошибка: разные операнды, либо неверные операнды, либо цифра < 1 или >10");
                System.exit(0);
            }
            //Если оба операнда римские, то ответ римский
          if (rimOrNot1 != -1)
          {
              switch (massExpression[1]) {
                  case "+" -> System.out.println(intToRom4ik(rimOrNot1 + rimOrNot2));
                  case "-" -> System.out.println(intToRom4ik(rimOrNot1 - rimOrNot2));
                  case "*" -> System.out.println(intToRom4ik(rimOrNot1 * rimOrNot2));
                  case "/" -> System.out.println(intToRom4ik(rimOrNot1 / rimOrNot2));
              }
              System.exit(0);
          }


        //Проверка на принадлежность условию
        try{
            if (massExpression[0].length() > 2 || massExpression[1].length() > 1 || massExpression[2].length() > 2)
                throw new Exception("Неверное количество символов в операторе или операндах");
        }
        catch (Exception ex) {
            System.out.println(ex.getMessage());
            System.exit(0);
        }

        //Проверка на числовую функциональность 1 операнда
        try{
            num1 = Integer.parseInt(massExpression[0]);
        }
        catch (Exception ex) {
            System.out.println("В ПЕРВОМ операнде есть не цифра");
            System.exit(0);
        }

        //Проверка числа на условие 1 операнда
        try {
            if (num1 > 10 || num1 < 1)
                throw new Exception("Значение 1 операнда меньше 1 или больше 10");
        }
        catch (Exception ex){
            System.out.println(ex.getMessage());
            System.exit(0);
        }

        //Проверка на числовую функциональность 2 операнда
        try{
            num2 = Integer.parseInt(massExpression[2]);
        }
        catch (Exception ex) {
            System.out.println("В ВТОРОМ операнде есть не цифра");
            System.exit(0);
        }

        //Проверка числа на условие 2 операнда
        try {
            if (num2 > 10 || num2 < 1)
                throw new Exception("Значение 2 операнда меньше 1 или больше 10");
        }
        catch (Exception ex){
            System.out.println(ex.getMessage());
            System.exit(0);
        }


        switch (massExpression[1]) {
            case "+" -> System.out.println(num1 + num2);
            case "-" -> System.out.println(num1 - num2);
            case "*" -> System.out.println(num1 * num2);
            case "/" -> System.out.println(num1 / num2);
            default -> System.out.println("Неверный оператор");
        }
    }
}
